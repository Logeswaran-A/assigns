﻿using System;

namespace PasswordVerification
{
    class Program
    {
        static void Main(string[] args)
        {
            Verification verification = new Verification();
            Console.WriteLine(verification.VerifyPassword("Prajjwal@18"));
        }
    }
}
