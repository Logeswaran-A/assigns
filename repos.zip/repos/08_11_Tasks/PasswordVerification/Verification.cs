﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace PasswordVerification
{
    class Verification
    {
        public const string passwordPattern = @"^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,32}$";
        public bool VerifyPassword(string password)
        {
            if(password != null)
            {
                return Regex.IsMatch(password, passwordPattern);
                
            }
            return false;
        }
    }
}
