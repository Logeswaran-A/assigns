﻿using Project04_11.Model;
using Project04_11.Repository;
using System;

namespace Project04_11
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee(1,"Prajjwal",15000,"18-01-2000");
            Manager mag1 = new Manager(2, "Abhi", 25000, "20-12-1988", 2000, 1000);

            SalaryCalculation salCal = new SalaryCalculation();
            double Sal = salCal.CalculateEmployeeSalary(emp1);
            Console.WriteLine(emp1.ToString());
            Console.WriteLine($"Annual Salary Of Employee: {Sal}");

            double SalM = salCal.CalculateManagerSalary(mag1);
            Console.WriteLine(mag1.ToString());
            Console.WriteLine($"Annual Salary of Manager: {SalM}");
        }
    }
}
