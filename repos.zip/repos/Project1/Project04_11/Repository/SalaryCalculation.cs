﻿using Project04_11.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Project04_11.Repository
{
    class SalaryCalculation
    {
        public double CalculateManagerSalary(Manager manager)
        {
            double Sal = manager.Salary + manager.OnSiteAllowance + manager.Bonus;
            return Sal * 12;
        }

        public double CalculateEmployeeSalary(Employee employee)
        {
            double Sal = employee.Salary * 12;
            return Sal;
        }
    }
}
