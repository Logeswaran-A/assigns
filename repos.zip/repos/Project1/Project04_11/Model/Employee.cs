﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project04_11.Model
{
    internal class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
        public string DateOfBrith { get; set; }

        public Employee(int EmpId,string EmpName,double EmpSalary,string EmpDateOfBirth)
        {
            Id = EmpId;
            Name = EmpName;
            Salary = EmpSalary;
            DateOfBrith = EmpDateOfBirth;

        }

        public override string ToString()
        {
            return $"Employee ID: {Id}   Name: {Name}   Salary: {Salary}  Date of Birth: {DateOfBrith}";
        }
    }
}
