﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project04_11.Model
{
    internal class Manager:Employee
    {
        public double OnSiteAllowance { get; set; }
        public double Bonus { get; set; }

        public Manager(int EmpId,string EmpName,double EmpSalary,string EmpDateOfBrith,double MagOnSite,double MagBonus):base(EmpId,EmpName,EmpSalary,EmpDateOfBrith)
        {
            OnSiteAllowance = MagOnSite;
            Bonus = MagBonus;
        }
    }
}
