﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Product obj1 = new Product("Television", 20000, 4.5);

            Console.WriteLine(obj1.GetProdutDetails());
            Console.WriteLine("Enter Quantity:");
            int quantity = int.Parse(Console.ReadLine());
            double total=obj1.GetTotalAmount(quantity);
            Console.WriteLine($"Total Amount to be Paid: {total}");
        }
    }
}
