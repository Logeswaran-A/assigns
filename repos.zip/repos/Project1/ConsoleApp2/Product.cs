﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class Product
    {
        public string productName;
        public int productPrice;
        public double rating;
        public Product(string productName, int productPrice, double rating)
        {
            this.productName = productName;
            this.productPrice = productPrice;
            this.rating = rating;
        }

        public Product() { }

        public string GetProdutDetails()
        {
            return $"Product Name: {productName}\tProduct Price: {productPrice}\tQuantity: {rating}";
        }

        public double GetTotalAmount(int quantity)
        {
            int product = productPrice * quantity;
            return (product + ((product/100) * 18));
        }
    }

    
}
