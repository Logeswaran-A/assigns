﻿using System;

namespace AppA
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Product Name");
            string productName = Console.ReadLine();
            Console.WriteLine("Enter Product Price");
            int productPrice =int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Product Quantity");
            int quantity = int.Parse(Console.ReadLine());
            float gst = 0;
            float total = 0;

            if(productPrice > 50000)
            {
                productPrice = (productPrice*quantity) - 1000;
                gst = (productPrice / 100) * 18;
                total = productPrice + gst;
                Console.WriteLine($"Product Name: {productName}\n Total Amount to be Paid: {total}");
                
            }
            else
            {
                productPrice = (productPrice*quantity);
                gst = (productPrice / 100) * 18;
                total = productPrice + gst;
                Console.WriteLine($"Product Name: {productName}\n Total Amount to be Paid: {total}");
            }

            
        }
    }
}
