﻿using System;

namespace Task2_04_11
{
    class Program
    {
        static void Main(string[] args)
        {
            PermanentTrainer permanentTrainer = new PermanentTrainer() {Id=1,Name="Prajjwal" };
            permanentTrainer.Salary = 50000;
            Console.WriteLine($"Salary Of Permananet Trainer:{permanentTrainer.TrainerSalary()}");
            FreelanceTrainer freelanceTrainer = new FreelanceTrainer() { Id = 2, Name = "Vedant" };
            freelanceTrainer.HourBasis = 1000;
            freelanceTrainer.TotalHour = 30;
            Console.WriteLine($"Salary of Freelance Trainer:{freelanceTrainer.TrainerSalary()}");
        }
    }
}
