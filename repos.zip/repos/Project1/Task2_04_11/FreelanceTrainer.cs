﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task2_04_11
{
    class FreelanceTrainer:Trainer
    {
        public int HourBasis { get; set; }

        public int TotalHour { get; set; }

        public override int TrainerSalary()
        {
            return HourBasis * TotalHour;

        }
    }
}
