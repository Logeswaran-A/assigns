﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task2_04_11
{
    class PermanentTrainer:Trainer
    {
        public int Salary { get; set; }

        public override int TrainerSalary()
        {
            return Salary;
        }

    }
}
