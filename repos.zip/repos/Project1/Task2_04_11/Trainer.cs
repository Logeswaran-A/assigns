﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task2_04_11
{
    internal abstract class Trainer
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return $"TrainerId: {Id}   Trainer Name: {Name}";
        }

        public abstract int TrainerSalary();

    }
}
