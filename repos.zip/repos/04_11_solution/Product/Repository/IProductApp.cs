﻿using System;
using Product.Model;
using System.Collections.Generic;
using System.Text;

namespace Product.Repository
{
    interface IProductApp
    {
        string ProductDetailsById(int product);

        bool AddProduct(ProductC product);
        
        bool DeleteProduct(int product);

        bool UpdateProduct(ProductC product);

        List<ProductC> GetAllProducts();

    }
}
