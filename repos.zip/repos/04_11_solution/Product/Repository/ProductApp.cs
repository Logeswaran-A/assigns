﻿using System;
using Product.Model;
using System.Collections.Generic;
using System.Text;

namespace Product.Repository
{
    class ProductApp:IProductApp
    {
        List<ProductC> products;

        public ProductApp()
        {
            products = new List<ProductC>()
            {
                new ProductC(1,"Laptop","Electronics",50000)
            };

        }

        public string ProductDetailsById(int product)
        {
            foreach(ProductC i in products)
            {
                if(i.ProductId == product)
                {
                    return i.ToString();
                }
            }
            return null;
        }

        public bool AddProduct(ProductC product)
        {
            products.Add(product);
            return true;
        }

        public bool DeleteProduct(int productId)
        {
            for(int i=0;i<products.Count;i++)
            {
                if(products[i].ProductId == productId)
                {
                    products.Remove(products[i]);
                    return true;
                }
            }
            return false;
        }

        public bool UpdateProduct(ProductC product)
        {
            foreach(ProductC i in products)
            {
                if(i.ProductId == product.ProductId)
                {
                    i.ProductName = product.ProductName;
                    i.ProductPrice = product.ProductPrice;
                    return true;
                }
            }
            return false;
        }

        public List<ProductC> GetAllProducts()
        {
            return products;
        }

        
    }
}
