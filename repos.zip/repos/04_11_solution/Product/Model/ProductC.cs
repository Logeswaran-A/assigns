﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Product.Model
{
    class ProductC
    {
        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public string ProductCategory { get; set; }
        public double ProductPrice { get; set; }

        public ProductC(int Id,string Pname,string Pcategory,double Pprice)
        {
            ProductId = Id;
            ProductName = Pname;
            ProductCategory = Pcategory;
            ProductPrice = Pprice;
        }

        public override string ToString()
        {
            return $"Product Id: {ProductId}  Product Name: {ProductName}  Product Category: {ProductCategory}  Product Price: {ProductPrice}";
        }
    }
}
