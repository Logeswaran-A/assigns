﻿using System;
using System.Collections.Generic;
using Product.Model;
using Product.Repository;

namespace Product
{
    class Program
    {
        static ProductApp productApp = new ProductApp();
        static void Main(string[] args)
        {
            
            
            bool flag = true;
            while(flag == true)
            { 
            string productsDetails = "1.Add Details\n2.Update Details\n3.Delete Product Details\n4.Get Product Details\n5.Exit";
            Console.WriteLine(productsDetails);
            Console.WriteLine("Enter Your Choice:");
            int key = int.Parse(Console.ReadLine());
            

           
                switch (key)
                {
                    case 1:

                        Console.WriteLine("Enter Product Id:");
                        int id = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Product Name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("Enter Product Category");
                        string category = Console.ReadLine();
                        Console.WriteLine("Enter Product Price");
                        double price = double.Parse(Console.ReadLine());
                        ProductC product = new ProductC(id, name, category, price);
                        productApp.AddProduct(product);
                        break;
                    case 2:
                        GetAllProduct();
                        Console.WriteLine("Enter Product Id to be updated");
                        int idU = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Product Name");
                        string pname = Console.ReadLine();
                        Console.WriteLine("Enter Product Category");
                        string pcat = Console.ReadLine();
                        Console.WriteLine("Enter Product Price");
                        double pprice = double.Parse(Console.ReadLine());
                        ProductC productU = new ProductC(idU, pname, pcat, pprice);
                        productApp.UpdateProduct(productU);
                        GetAllProduct();
                        break;
                    case 3:
                        Console.WriteLine("Enter Product Id to be Deleted:");
                        int productIdtobeDeleted = int.Parse(Console.ReadLine());
                        productApp.DeleteProduct(productIdtobeDeleted);
                        GetAllProduct();
                        break;

                    case 4:
                        GetAllProduct();
                        break;
                    case 5:
                        flag = false;
                        break;


                }
            }
        }
        public static void GetAllProduct()
        {
            List<ProductC> prod;
            prod = productApp.GetAllProducts();
            foreach (ProductC i in prod)
            {
                Console.WriteLine(i.ToString());
            }
        }
    }
}
