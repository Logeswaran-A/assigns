﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ipl20
{
    class Player
    {
        public string PlayerName { get; set; }
        //public long Runs { get; set; }

        public long CapNumber { get; set; }

        public string Skill { get; set; }

        public Player(string playerName,long capNumber,string skill)
        {
            PlayerName = playerName;
            //Runs = runs;
            CapNumber = capNumber;
            Skill = skill;
        }

        public Player()
        {

        }

        public override string ToString()
        {
            return $"{CapNumber} {PlayerName}  {Skill}";
        }
    }
}
