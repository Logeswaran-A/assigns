﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ipl20
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Player> players = new List<Player>();
            Console.WriteLine("Enter Number of Players");
            int playerCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < playerCount; i++)
            {
                Console.WriteLine("Enter Player Names");
                string name = Console.ReadLine();
                Console.WriteLine("Enter Cap Number");
                long cap = long.Parse(Console.ReadLine());
                Console.WriteLine("Enter Skill");
                string skill = Console.ReadLine();
                players.Add(new Player(name, cap,skill));
            }

            //Using query Syntax LINQ 1
            Console.WriteLine("--------LINQ query 1--------");
            var playerDetails = from player in players
                                    select player;

                Console.WriteLine("PlayerList:");
                foreach(var player in playerDetails)
                {
                   Console.WriteLine(player.ToString());
                }


            //Using query Syntax LINQ 2
            //Console.WriteLine("--------LINQ query 2--------");
            //var playerDetailsAbove50 = from player in players
            //                           where player.Runs >= 50
            //                           select player;
            //foreach (var player in playerDetailsAbove50)
            //{
            //    Console.WriteLine(player.ToString());
            //}

            //Using Query Syntax LINQ 3
            Console.WriteLine("--------LINQ query 3--------");
            var playerDetailsDistinct = from player in players
                                        select players.Distinct();
            foreach(var i in players)
            {
                Console.WriteLine(i.ToString());
            }    
        }
    }
}
