﻿using System;
using System.Collections.Generic;

namespace CSK
{
    class Program
    {
        static List<string> playerList = new List<string>();
        
        static void Main(string[] args)
        {
            playerList.Add("MS Dhoni");
            Operations();
            GetAllPlayers();
            
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("Do you want to Continue");
                string choice = Console.ReadLine();
                if (choice.ToLower() == "yes")
                {
                    Operations();
                }
                else
                {
                    flag = false;
                }
                GetAllPlayers();
            }
            
        }

        public static void Operations()
        {
           
          
                GetAllPlayers();
                Console.WriteLine("Menu\n1.Insert Player\n2.Delete Player");
                int key = int.Parse(Console.ReadLine());
                switch (key)
                {
                    case 1:
                        Console.WriteLine("Enter Player Name");
                        string playerNameAdd = Console.ReadLine();
                        playerList.Add(playerNameAdd);
                        break;
                    case 2:
                        Console.WriteLine("Enter Player Name to be Deleted");
                        string playerNameDel = Console.ReadLine();
                        playerList.Remove(playerNameDel);
                        break;
                    default:
                        Console.WriteLine("Invalid Choice!!!!");
                            break;
                }
            
        }

        public static void GetAllPlayers()
        {
            
            Console.WriteLine(playerList.Count);
            foreach (string i in playerList)
            {
                Console.WriteLine(i);
            }
        }
    }
}
