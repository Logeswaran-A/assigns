﻿using System;

namespace RunRate
{
    class Program
    {
        static void Main(string[] args)
        {
            
            try
            {
                Console.WriteLine("Enter Runs");
                int runs = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Overs");
                int overs = int.Parse(Console.ReadLine());
                double runRate = runs/overs;
                Console.WriteLine($"Run Rate is:{Math.Round(runRate,2)}");
            }
            catch(FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Exception Handled");
            }
           
        }
    }
}
