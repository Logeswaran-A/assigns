﻿using System;
using System.Collections.Generic;

namespace Cricket
{
    class Program
    {
        static List<List<string>> players = new List<List<string>>();
        static void Main(string[] args)
        {
            bool flag = true;
            while(flag==true)
            {
                Console.WriteLine("1.Add Player\n2.Remove Player");
                int key = int.Parse(Console.ReadLine());
                switch(key)
                {
                    case 1:
                        AddPlayer();
                        break;
                    case 2:
                        RemovePlayer();
                        break;
                    default:
                        flag = false;
                        break;
                }
            }
        }

        public static void AddPlayer()
        {
            Console.WriteLine("Enter Player Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Player Age");
            string age = Console.ReadLine();
            Console.WriteLine("Enter Country");
            string country = Console.ReadLine();
            List<string> subList = new List<string>() { name, age, country };
            players.Add(subList);
            PrintPlayerDetails();
            Console.WriteLine("Enter Player Skill");
            string skill = Console.ReadLine();
            Console.WriteLine("Enter Position you want to add skill");
            int position = int.Parse(Console.ReadLine());
            subList.Insert(position, skill);
            PrintPlayerDetails();
        }

        public static void PrintPlayerDetails()
        {
            foreach(List<string> i in players)
            {
                foreach(string j in i)
                {
                    Console.WriteLine(j);
                }
            }
            Console.WriteLine("---------------------");
        }

        public static void RemovePlayer()
        {
            PrintPlayerDetails();
            Console.WriteLine("Enter Player Name Whose details you want to remove:");
            string name = Console.ReadLine();
            foreach(List<string> i in players)
            {
                if(i.Contains(name))
                {
                    List<string> subList1 = i;
                    Console.WriteLine("Enter Position of details you want to remove:");
                    int pos = int.Parse(Console.ReadLine());
                    subList1.RemoveAt(pos);

                }
            }
            PrintPlayerDetails();
        }
    }
}
